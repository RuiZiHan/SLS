import os
#from util.crop import RandomResizedCrop
from timm.data.constants import IMAGENET_INCEPTION_MEAN, IMAGENET_INCEPTION_STD, IMAGENET_DEFAULT_MEAN, \
    IMAGENET_DEFAULT_STD
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from torchvision import transforms
import torch
import PIL
import math
from timm.data.constants import IMAGENET_INCEPTION_MEAN, IMAGENET_INCEPTION_STD, IMAGENET_DEFAULT_MEAN, \
    IMAGENET_DEFAULT_STD

class RandomResizedCrop(transforms.RandomResizedCrop):
    """
    RandomResizedCrop for matching TF/TPU implementation: no for-loop is used.
    This may lead to results different with torchvision's version.
    Following BYOL's TF code:
    https://github.com/deepmind/deepmind-research/blob/master/byol/utils/dataset.py#L206
    """

    @staticmethod
    def get_params(img, scale, ratio):
        assert isinstance(img, PIL.Image.Image)
        # width, height = F._get_image_size(img)
        width, height = img.width, img.height
        area = height * width

        target_area = area * torch.empty(1).uniform_(scale[0], scale[1]).item()
        log_ratio = torch.log(torch.tensor(ratio))
        aspect_ratio = torch.exp(
            torch.empty(1).uniform_(log_ratio[0], log_ratio[1])
        ).item()

        w = int(round(math.sqrt(target_area * aspect_ratio)))
        h = int(round(math.sqrt(target_area / aspect_ratio)))

        w = min(w, width)
        h = min(h, height)

        i = torch.randint(0, height - h + 1, size=(1,)).item()
        j = torch.randint(0, width - w + 1, size=(1,)).item()

        return i, j, h, w

def build_image_dataset(args):
    # linear probe: weak augmentation
    # if os.path.basename(args.finetune).startswith(
    #         'vit_base_p16'):  # 预训练模型 vit-B/16 trained on imagenet21k,then fine-tuned on imagenet1k
    #     # _mean = IMAGENET_INCEPTION_MEAN
    #     # _std = IMAGENET_INCEPTION_STD
    #     _mean = IMAGENET_DEFAULT_MEAN
    #     _std = IMAGENET_DEFAULT_STD
    # elif os.path.basename(args.finetune).startswith('mae_pretrain_vit'):
    #     _mean = IMAGENET_DEFAULT_MEAN
    #     _std = IMAGENET_DEFAULT_STD
    # elif os.path.basename(args.finetune).startswith('swin_base_patch'):
    #     _mean = IMAGENET_DEFAULT_MEAN
    #     _std = IMAGENET_DEFAULT_STD
    # elif os.path.basename(args.finetune).startswith('jx'):
    #     # _mean = IMAGENET_INCEPTION_MEAN
    #     # _std = IMAGENET_INCEPTION_STD
    #     _mean = IMAGENET_DEFAULT_MEAN
    #     _std = IMAGENET_DEFAULT_STD
    # else:
    #     raise ValueError(os.path.basename(args.finetune))

    _mean = IMAGENET_DEFAULT_MEAN
    _std = IMAGENET_DEFAULT_STD
    transform_train = transforms.Compose([
        RandomResizedCrop(224, interpolation=3),
        transforms.RandomHorizontalFlip(),
        #transforms.Resize((224, 224), interpolation=3),
        transforms.ToTensor(),
        transforms.Normalize(mean=_mean, std=_std)])
    transform_val = transforms.Compose([
        transforms.Resize(256, interpolation=3),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=_mean, std=_std)])

    if args.dataset == 'imagenet':
        dataset_train = datasets.ImageFolder(os.path.join(args.data_path, 'train'), transform=transform_train)
        dataset_val = datasets.ImageFolder(os.path.join(args.data_path, 'val'), transform=transform_val)
        nb_classes = 1000

    elif args.dataset == 'cifar':
        dataset_train = datasets.CIFAR100(os.path.join('/root/autodl-tmp/datasets/', 'cifar100'), transform=transform_train,
                                          train=True, download=True)
        dataset_val = datasets.CIFAR100(os.path.join('/root/autodl-tmp/datasets/', 'cifar100'), transform=transform_val, train=False,
                                        download=True)
        nb_classes = 100

    # elif args.dataset == 'flowers102':
    #     from .flowers102 import Flowers102
    #     dataset_train = Flowers102(os.path.join(args.data_path, 'flowers102'), split='train', transform=transform_train,
    #                                download=True)
    #     dataset_val = Flowers102(os.path.join(args.data_path, 'flowers102'), split='test', transform=transform_val,
    #                              download=True)
    #     nb_classes = 102

    elif args.dataset == 'svhn':
        from torchvision.datasets import SVHN
        dataset_train = SVHN(os.path.join(args.data_path, 'svhn'), split='train', transform=transform_train,
                             download=True)
        dataset_val = SVHN(os.path.join(args.data_path, 'svhn'), split='test', transform=transform_val, download=True)
        nb_classes = 10
    # elif args.dataset == 'food101':
    #     from .food101 import Food101
    #     dataset_train = Food101(os.path.join(args.data_path, 'food101'), split='train', transform=transform_train,
    #                             download=True)
    #     dataset_val = Food101(os.path.join(args.data_path, 'food101'), split='test', transform=transform_val,
    #                           download=True)
    #     nb_classes = 101
    else:
        raise ValueError(args.dataset)

    return dataset_train, dataset_val, nb_classes
