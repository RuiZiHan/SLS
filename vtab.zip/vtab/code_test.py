import datetime
import os
import time

import timm
import torch
from matplotlib import pyplot as plt
from torch.optim import AdamW
from torch.optim import SGD
import torch.nn as nn
from torch.nn import functional as F
from avalanche.evaluation.metrics.accuracy import Accuracy
from torch_cka.utils import add_colorbar
from tqdm import tqdm
from timm.models import create_model
from timm.scheduler.cosine_lr import CosineLRScheduler
from argparse import ArgumentParser
from vtab import *
from utils import *
from einops import *
import torch.utils.data as data
from sklearn.cluster import KMeans
from sklearn.datasets import load_iris
from sklearn.metrics import silhouette_score
import numpy as np
from convpass import set_Convpass, QuickGELU
from try_code import set_drop_backbone, set_limited_convpass, backbone_weight_fusioin, \
    set_mixAdapter, set_Side_Adapter, set_layer_forward, set_block_forward
import nni
from nni.utils import merge_parameter
from fine_tune.engine_finetune import train_one_epoch, evaluate
import torch.backends.cudnn as cudnn
from fine_tune.misc import NativeScalerWithGradNormCount as NativeScaler
import fine_tune.misc as misc
import math
import json
from PIL import Image
import pandas as pd
from sota_pruning import validate_model

from pruning_train import load

# model = create_model('vit_base_patch16_224_in21k', checkpoint_path='/root/autodl-tmp/pre_train/ViT-B_16.npz',
#                      drop_path_rate=0.1)
#
# model.reset_classifier(10)
#
# set_Convpass(model, 'convpass', dim=8, s=1, xavier_init=False)
#
# loss = nn.CrossEntropyLoss()
#
# x = torch.tensor([[1, 1, 1]], dtype=torch.float)
# y = torch.tensor([[1, 0, 0]], dtype=torch.float)


# /root/autodl-tmp/datasets/imagenet/mini-imagenet-sxc/val.csv
# /root/autodl-tmp/datasets/imagenet/mini-imagenet-sxc/images

# df = pd.read_csv('/root/autodl-tmp/datasets/imagenet/mini-imagenet-sxc/val.csv')
# print(df)


# x, y = load_iris(return_X_y=True)
# print(x.shape)
# model = KMeans(n_clusters=3)
# model.fit(x)
# y_pred = model.predict(x)
# print(y_pred.shape)
# print(f"轮廓系数 by sklearn: {silhouette_score(x, y)}")


model = create_model('vit_base_patch16_224_in21k', checkpoint_path='/root/autodl-tmp/pre_train/ViT-B_16.npz',
                     drop_path_rate=0.1)
config = get_config('convpass', 'dtd')
set_Convpass(model, 'convpass', dim=8, s=config['scale'], xavier_init=config['xavier_init'])
set_drop_backbone(model, 10)
model.reset_classifier(config['class_num'])
model = load('dtd', model, 'convpass', model_struct='ViT', blocks=12)

model = model.to('cuda')
train_dl, test_dl = get_data('dtd', evaluate=True)

acc, loss = validate_model(model, test_dl, 'cuda')
print(f'acc={acc},loss={loss}')

# print(model)


# `.bst`（BibTeX style file）是一种用于处理引用和参考文献格式的文件。在LaTeX文档中，可以使用BibTeX引擎和`.bst`文件来自动处理引用格式和参考文献列表的生成。
#
# `.bst`文件定义了参考文献的样式，包括作者、标题、期刊名称、出版信息等的格式。它决定了引用和参考文献在文档中的外观和顺序。不同的学术领域、期刊和出版机构可能使用不同的`.bst`文件来满足其特定的引用和参考文献格式要求。
#
# 常见的一些`.bst`文件包括`plain.bst`、`IEEEtran.bst`、`apalike.bst`等。可以在LaTeX文档中通过`\bibliographystyle{}`命令指定使用哪个`.bst`文件，并通过`\bibliography{}`命令指定引用的文献数据库文件（通常是`.bib`文件）。然后可以使用`\cite{}`命令在文档中引用文献，BibTeX会根据指定的`.bst`文件自动生成格式化的引用和参考文献列表。
#
# 总之，`.bst`文件是定义引用和参考文献样式的文件，用于在LaTeX中自动处理引用格式和生成参考文献列表。
