import json


def main(method: str, dataset: str):
    path = "/root/autodl-tmp/convpass/vtab/search_result/" + method + '_' + dataset + ".json"
    with open(path, 'r') as f:
        search_result = json.loads(f.read())
    result_dict = {"params": None, "acc": 0.}
    max_acc = 0.
    for trail in search_result["trialMessage"]:
        if trail["status"] == "SUCCEEDED":
            if float(json.loads(trail["finalMetricData"][0]["data"])) > max_acc:
                max_acc = float(json.loads(trail["finalMetricData"][0]["data"]))
                result_dict["params"] = json.loads(trail["hyperParameters"][0])["parameters"]
                result_dict["acc"] = max_acc
    return result_dict


if __name__ == "__main__":
    print(main("Drop4", "CIFAR"))
