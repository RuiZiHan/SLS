import datetime
import os
import time
from copy import deepcopy

import torch
from torch.optim import AdamW
from torch.optim import SGD
from torch.nn import functional as F
from avalanche.evaluation.metrics.accuracy import Accuracy
from tqdm import tqdm
from timm.models import create_model
from timm.scheduler.cosine_lr import CosineLRScheduler
from argparse import ArgumentParser
from vtab import *
from utils import *
from convpass import set_Convpass
from try_code import set_drop_backbone, set_limited_convpass, backbone_weight_fusioin, \
    set_mixAdapter, set_Side_Adapter, set_layer_forward, set_block_forward
import nni
from nni.utils import merge_parameter
from fine_tune.engine_finetune import train_one_epoch, evaluate
import torch.backends.cudnn as cudnn
from fine_tune.misc import NativeScalerWithGradNormCount as NativeScaler
import fine_tune.misc as misc
import math
import json


@torch.no_grad()
def save(dataset, model, blocks=12):
    model.eval()
    model = model.cpu()
    trainable = {}
    for n, p in model.named_parameters():
        if 'adapter' in n or 'head' in n:
            trainable[n] = p.data
    torch.save(trainable, f"/root/autodl-tmp/output_ours/{dataset}_{blocks}blocks.pt")


def load(dataset, model, blocks=12):
    model = model.cpu()
    st = torch.load(f"/root/autodl-tmp/output_ours/{dataset}_{blocks}blocks.pt")
    model.load_state_dict(st, False)
    return model


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--insert_scale', type=float, default=10)
    parser.add_argument('--wd', type=float, default=1e-4)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--warmup_epochs', type=int, default=10)
    parser.add_argument('--start_epoch', default=0, type=int)
    parser.add_argument('--min_lr', type=float, default=0.)
    parser.add_argument('--class_num', type=int, default=100)
    parser.add_argument('--turnon_distill', default=False)
    parser.add_argument('--distill_rate', type=float, default=5e-3)
    parser.add_argument('--fulltune', default=False)
    parser.add_argument('--device', default='cuda')
    # swin_base_patch4_window7_224_in22k
    # vit_base_patch16_224_in21k
    parser.add_argument('--model', type=str, default='vit_base_patch16_224_in21k')
    parser.add_argument('--dataset', type=str, default='cifar')
    parser.add_argument('--method', type=str, default='convpass')
    parser.add_argument('--output_dir', type=str, default='/root/autodl-tmp/output_convpass')

    args = parser.parse_args()
    # 在 args = parser.parse_args() 获取args后，添加这两行代码，将搜索到的超参数更新agrs，以便于传递给模型
    nni_params = nni.get_next_parameter()
    args = merge_parameter(args, nni_params)

    print(args)

    if torch.cuda.is_available():
        device = torch.device(args.device)  # 定义模型运行的设备，默认cuda
    else:
        device = 'cpu'
    cudnn.benchmark = True  # 提升运行速度

    set_seed(args.seed)
    config = get_config(args.method, args.dataset)
    args.class_num = config['class_num']
    # /root/autodl-tmp/pre_train/ViT-B_16.npz

    model = create_model(args.model, checkpoint_path='/root/autodl-tmp/pre_train/ViT-B_16.npz',
                         drop_path_rate=0.1)
    print(model)

    set_Convpass(model, args.method, dim=8, s=config['scale'], xavier_init=config['xavier_init'])

    start_time = time.time()

    for i in range(5):  # 0-4
        if i != 4:
            train_dl, test_dl = get_data(args.dataset, evaluate=False)
        else:
            train_dl, test_dl = get_data(args.dataset, evaluate=True)
        print(f"fine-tuning {12 - i} block backbone")

        if i != 0:
            teacher_model = load(args.dataset, model, blocks=12)
            # set_drop_backbone(teacher_model, current_depth=13 - i)
            teacher_model = teacher_model.to(device)

        set_drop_backbone(model, current_depth=12 - i)

        model.reset_classifier(config['class_num'])

        if i != 0:
            model = load(args.dataset, model, blocks=13 - i)

        for name, p in model.named_parameters():
            if 'adapt' in name or 'learnable_gate' in name:
                p.requires_grad = True
                print(name)
            else:
                p.requires_grad = False if not args.fulltune else True

        for _, p in model.head.named_parameters():  # 再单独将head设为true
            p.requires_grad = True

        model = model.to(device)

        config['best_acc'] = 0
        config['method'] = args.method
        n_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)
        n_parameters_head = sum(p.numel() for p in model.head.parameters() if p.requires_grad)
        n_parameters = n_parameters - n_parameters_head

        print('number of params (M): %.2f' % (n_parameters / 1.e6))

        opt = AdamW([p for name, p in model.named_parameters() if p.requires_grad], lr=args.lr, weight_decay=args.wd)

        log_writer = None
        loss_scaler = NativeScaler()
        criterion = torch.nn.CrossEntropyLoss()
        print("criterion = %s" % str(criterion))
        # if i != 0 and i != 4:
        #     args.epochs = 30

        print(f"Start training for {args.epochs} epochs")
        max_accuracy = 0.0

        for epoch in range(args.start_epoch, args.epochs):  # args.start_epoch->args.epochs-1
            model = model.to(device)
            train_stats = train_one_epoch(
                model, criterion, train_dl,
                opt, device, epoch, loss_scaler,
                max_norm=None,
                log_writer=log_writer,
                args=args,
                teacher_model=teacher_model if i != 0 else None
            )

            test_stats = evaluate(test_dl, model, device, args=args)
            if args.output_dir and test_stats["acc1"] > max_accuracy:
                save(args.dataset, model, blocks=12 - i)
            print(f"Accuracy of the network on the {len(test_dl.dataset)} test images: {test_stats['acc1']:.1f}%")
            max_accuracy = max(max_accuracy, test_stats["acc1"])

            nni.report_intermediate_result(test_stats["acc1"])

            print(f'Max accuracy: {max_accuracy:.2f}%')

            if log_writer is not None:
                log_writer.add_scalar('perf/test_acc1', test_stats['acc1'], epoch)
                log_writer.add_scalar('perf/test_acc5', test_stats['acc5'], epoch)
                log_writer.add_scalar('perf/test_loss', test_stats['loss'], epoch)

            log_stats = {**{f'train_{k}': v for k, v in train_stats.items()},
                         **{f'test_{k}': v for k, v in test_stats.items()},
                         'epoch': epoch,
                         'n_parameters': n_parameters}

            if args.output_dir and misc.is_main_process():
                if log_writer is not None:
                    log_writer.flush()
                with open(os.path.join(args.output_dir, "log.txt"), mode="a", encoding="utf-8") as f:
                    f.write(json.dumps(log_stats) + "\n")

            # test_stats = evaluate(test_dl, model, device, args=args)
            # if args.output_dir and test_stats["acc1"] > max_accuracy:
            #     max_acc_index = epoch
            #     save(args.dadataset, model)
            #     # misc.save_model(
            #     #     args=args, model=model, model_without_ddp=model, optimizer=opt,
            #     #     loss_scaler=loss_scaler, epoch=epoch)
            #
            # GB = 1024.0 * 1024.0 * 1024.0
            # print(f"Accuracy of the network on the {len(test_dl.dataset)} test images: {test_stats['acc1']:.1f}%")
            # max_accuracy = max(max_accuracy, test_stats["acc1"])
            #
            # nni.report_intermediate_result(test_stats["acc1"])
            #
            # pme = test_stats["acc1"] * math.exp(
            #     -1 * math.log(n_parameters / 1.e8 + (torch.cuda.max_memory_allocated() / 1024) / (20 * GB) + 1, 10))
            # print('Parameter-Memory Efficiency:', pme)
            # max_pme = max(max_pme, pme)
            #
            # print(f'Max accuracy: {max_accuracy:.2f}%')
            # print(f'Max PME: {max_pme:.2f}')
            #
            # if log_writer is not None:
            #     log_writer.add_scalar('perf/test_acc1', test_stats['acc1'], epoch)
            #     log_writer.add_scalar('perf/test_acc5', test_stats['acc5'], epoch)
            #     log_writer.add_scalar('perf/test_loss', test_stats['loss'], epoch)
            #
            # log_stats = {**{f'train_{k}': v for k, v in train_stats.items()},
            #              **{f'test_{k}': v for k, v in test_stats.items()},
            #              'epoch': epoch,
            #              'n_parameters': n_parameters}
            #
            # if args.output_dir and misc.is_main_process():
            #     if log_writer is not None:
            #         log_writer.flush()
            #     with open(os.path.join(args.output_dir, "log.txt"), mode="a", encoding="utf-8") as f:
            #         f.write(json.dumps(log_stats) + "\n")

        if i == 4:
            with open('/root/autodl-tmp/output_ours/%s.log' % args.dataset, mode="a") as f:
                f.write(str(max_accuracy) + "\n")

        total_time = time.time() - start_time
        total_time_str = str(datetime.timedelta(seconds=int(total_time)))
        print('Training time {}'.format(total_time_str))

        nni.report_final_result(max_accuracy)

        print(config['best_acc'])
