# 定义你的超参数搜索空间
# 书写格式参考如下
# '_type'表示数据类型，分为三类：
# 'loguniform':从给定范围的对数均匀分布采样
# 'choice':从给定的数组中选择一个
# 'uniform':从给定的均匀分布采样
# '_value':给定搜索范围
search_space = {
    'insert_scale': {'_type': 'choice', '_value': [0.01, 0.1, 1.0, 10, 100]},
}

from nni.experiment import Experiment

experiment = Experiment('local')

experiment.config.trial_command = 'python train.py'#命令行运行你的主程序
experiment.config.trial_code_directory = '.'#主程序的路径相对于本文件的位置

experiment.config.search_space = search_space

experiment.config.tuner.name = 'TPE'#定义超参数搜索方法(有网格类，贝叶斯类，启发式类)
experiment.config.tuner.class_args['optimize_mode'] = 'maximize'

experiment.config.max_trial_number = 40#一共要尝试多少组超参数
experiment.config.trial_concurrency = 1#同时训练实验的个数

experiment.run(6006)#设定运行的端口，运行后一般在本机上运行 127.0.0.1:端口(命令行会给出提示) 就能打开web界面
