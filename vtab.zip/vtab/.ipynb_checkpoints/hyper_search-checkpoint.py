search_space = {
    'lr': {'_type': 'choice', '_value': [0.1, 0.05, 0.01, 0.005, 0.001]},
    'insert_scale': {'_type': 'choice', '_value': [0.01, 0.05, 0.1, 0.5, 1.0, 5.0, 10, 100]},
}

from nni.experiment import Experiment

experiment = Experiment('local')

experiment.config.trial_command = 'python train.py'
experiment.config.trial_code_directory = '.'

experiment.config.search_space = search_space

experiment.config.tuner.name = 'TPE'
experiment.config.tuner.class_args['optimize_mode'] = 'maximize'

experiment.config.max_trial_number = 100
experiment.config.trial_concurrency = 1

experiment.run(6006)
