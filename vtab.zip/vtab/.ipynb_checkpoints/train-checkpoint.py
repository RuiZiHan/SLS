import torch
from torch.optim import AdamW
from torch.optim import SGD
from torch.nn import functional as F
from avalanche.evaluation.metrics.accuracy import Accuracy
from tqdm import tqdm
from timm.models import create_model
from timm.scheduler.cosine_lr import CosineLRScheduler
from argparse import ArgumentParser
from vtab import *
from utils import *
from convpass import set_Convpass
from try_code import set_conv_attn
import nni
from nni.utils import merge_parameter


def train(config, model, dl, opt, scheduler, epoch):
    model.train()
    model = model.cuda()
    for ep in tqdm(range(epoch)):
        model.train()
        model = model.cuda()
        for i, batch in enumerate(dl):
            x, y = batch[0].cuda(), batch[1].cuda()
            out = model(x)
            loss = F.cross_entropy(out, y)
            # print(loss.item())
            opt.zero_grad()
            loss.backward()
            opt.step()
        if scheduler is not None:
            scheduler.step(ep)
        # if ep % 10 == 9:
        acc = test(model, test_dl)
        print("\nmax memory usage:", torch.cuda.max_memory_allocated() / 1.e6, 'M')
        print("test acc=",acc * 100, '%')
        
        nni.report_intermediate_result(acc * 100)
        
        if acc > config['best_acc']:
            config['best_acc'] = acc
            save(config['method'], config['name'], model, acc, ep)
            
    nni.report_final_result(config['best_acc']* 100)
    
    model = model.cpu()
    return model


@torch.no_grad()
def test(model, dl):
    model.eval()
    acc = Accuracy()
    model = model.cuda()
    for batch in dl:  # pbar:
        x, y = batch[0].cuda(), batch[1].cuda()
        out = model(x).data
        acc.update(out.argmax(dim=1).view(-1), y, 0)

    return acc.result()[0]


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--lr', type=float, default=1e-2)
    parser.add_argument('--insert_scale', type=float, default=0.1)
    parser.add_argument('--wd', type=float, default=1e-4)
    parser.add_argument('--model', type=str, default='vit_base_patch16_224_in21k')
    parser.add_argument('--dataset', type=str, default='dsprites_loc')
    parser.add_argument('--method', type=str, default='convpass')
    args = parser.parse_args()
    
    nni_params = nni.get_next_parameter()
    args = merge_parameter(args, nni_params)
    
    print(args)
    set_seed(args.seed)
    config = get_config(args.method, args.dataset)
    model = create_model(args.model, checkpoint_path='/root/autodl-tmp/pre_train/ViT-B_16.npz', drop_path_rate=0.1)
    print(model)

    train_dl, test_dl = get_data(args.dataset)

    # set_Convpass(model, args.method, dim=8, s=config['scale'], xavier_init=config['xavier_init'])
    set_Convpass(model, args.method, dim=8, s=args.insert_scale, xavier_init=config['xavier_init'])
    # set_conv_attn(model, args.method, dim=8, s=config['scale'], xavier_init=config['xavier_init'])

    trainable = []
    model.reset_classifier(config['class_num'])

    config['best_acc'] = 0
    config['method'] = args.method

    for n, p in model.named_parameters():
        if 'conv_attn' in n or 'adapter' in n or 'head' in n:
            trainable.append(p)
            print(n)
        else:
            p.requires_grad = False

    n_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print('number of params (M): %.2f' % (n_parameters / 1.e6))

    opt = AdamW(trainable, lr=args.lr, weight_decay=args.wd)
    # opt = SGD(trainable, lr=args.lr, momentum=0.9, weight_decay=args.wd)
    scheduler = CosineLRScheduler(opt, t_initial=40,
                                  warmup_t=10, lr_min=1e-5, warmup_lr_init=1e-6, decay_rate=0.1)
    model = train(config, model, train_dl, opt, scheduler, epoch=40)
    print(config['best_acc'])
