import timm
import torch
from torch.optim import AdamW
from torch.nn import functional as F
import torch.nn as nn
from avalanche.evaluation.metrics.accuracy import Accuracy
from tqdm import tqdm
from timm.models import create_model
from timm.scheduler.cosine_lr import CosineLRScheduler
from argparse import ArgumentParser
from vtab import *
from utils import *

import math
from conv_attn import conv_attn


def forward_block(self, x):
    x = x + self.drop_path(self.attn(self.norm1(x))) + self.drop_path(self.adapter_attn(self.norm1(x))) * self.s
    x = x + self.drop_path(self.mlp(self.norm2(x))) + self.drop_path(self.adapter_mlp(self.norm2(x))) * self.s
    return x


def forward_block_attn(self, x):
    x = x + self.drop_path(self.attn(self.norm1(x))) + self.drop_path(self.adapter_attn(self.norm1(x))) * self.s
    x = x + self.drop_path(self.mlp(self.norm2(x)))
    return x


def forward_Attn_attn(self, x):
    B, N, C = x.shape
    qkv = self.qkv(x).reshape(B, N, 3, 8, 96).permute(2, 0, 3, 1, 4)
    q, k, v = qkv.unbind(0)

    #q, k = self.q_norm(q), self.k_norm(k)

    y = self.conv_attn(q, k, v)

    # if self.fused_attn:
    #     x = F.scaled_dot_product_attention(
    #         q, k, v,
    #         dropout_p=self.attn_drop.p,
    #     )
    # else:
    q = q * self.scale
    attn = q @ k.transpose(-2, -1)
    attn = attn.softmax(dim=-1)
    attn = self.attn_drop(attn)
    x = attn @ v

    x = x.transpose(1, 2).reshape(B, N, C)
    x = self.proj(x)
    x = self.proj_drop(x)
    return x + y * self.s


def set_conv_attn(model, method, dim=8, s=1, xavier_init=False):
    for _ in model.children():
        # if type(_) == timm.models.vision_transformer.Block:
        #     _.adapter_attn = conv_attn(768, 8)
        #     # _.adapter_mlp = conv_attn(768, 8)
        #     _.s = s
        #     bound_method = forward_block_attn.__get__(_, _.__class__)
        #     setattr(_, 'forward', bound_method)å
        if type(_) == timm.models.vision_transformer.Attention:
            _.conv_attn = conv_attn(768, 8)
            _.s = s
            bound_method = forward_Attn_attn.__get__(_, _.__class__)
            setattr(_, 'forward', bound_method)
        elif len(list(_.children())) != 0:
            set_conv_attn(_, method, dim, s, xavier_init)
            

model = create_model('vit_base_patch16_224_in21k', checkpoint_path='/root/autodl-tmp/pre_train/ViT-B_16.npz', drop_path_rate=0.1)   

print(model)
